# Contributing to Emotional AI Manifesto

Thank you for your interest in contributing! Please follow these steps:

1. Fork the repository
2. Create a branch: `git checkout -b feature-name`
3. Commit your changes and open a Pull Request
